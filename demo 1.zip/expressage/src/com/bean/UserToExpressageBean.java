package com.bean;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.util.Constant;
import com.util.DBO;

public class UserToExpressageBean {

	
	private int id;
	private int userid;
	private int expressageid;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getExpressageid() {
		return expressageid;
	}
	public void setExpressageid(int expressageid) {
		this.expressageid = expressageid;
	}
	
	public int insert (int userid,int expressageid) {
	
			DBO dbo = new DBO();
			dbo.open();
			try{
				int i = dbo.executeUpdate("insert into t_userToexpressages (userid,expressageid) " +
						"values('"+userid+"','"+expressageid+"')");
				if(i == 1){
					return Constant.SUCCESS;
				}
				else{
					return Constant.SYSTEM_ERROR;
				}
			}catch(Exception e){
				e.printStackTrace();
				return Constant.SYSTEM_ERROR;
			}finally{
				dbo.close();
			}

	}
	public int isExist(int userid2, int expressageid2) {
        ResultSet rs=null;
        
		DBO dbo = new DBO();
		dbo.open();
			try {
				rs = dbo.executeQuery("select * from t_userToexpressages where userid='"+userid2+"'and expressageid='"+expressageid2+"'");
			if(rs.next()){
					return Constant.SUCCESS;
				}
				else{
					return Constant.SYSTEM_ERROR;
					
				}	}
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 return Constant.SYSTEM_ERROR;
	
	
	}
	
	
public static void main(String []args)
{
	UserToExpressageBean ub=new UserToExpressageBean();
	ub.insert(1, 1);
	
}

	
	
	
}
