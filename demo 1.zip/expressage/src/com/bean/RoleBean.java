package com.bean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.util.Constant;
import com.util.DBO;

public class RoleBean {
private int id;
private String name;
private String description;
private Boolean isDeleted;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Boolean getIsDeleted() {
	return isDeleted;
}
public void setIsDeleted(Boolean isDeleted) {
	this.isDeleted = isDeleted;
}
@Override
public String toString() {
	return "RoleBean [description=" + description + ", id=" + id
			+ ", isDeleted=" + isDeleted + ", name=" + name + "]";
}
/**
 * 
 * @param rs
 * @return
 * @throws SQLException
 */
private RoleBean toModel(ResultSet rs) throws SQLException {
	
	RoleBean roleBean=new RoleBean();
	roleBean.setId(rs.getInt("id"));
	roleBean.setIsDeleted(rs.getBoolean("isDeleted"));
	roleBean.setName(rs.getString("name"));
	roleBean.setDescription(rs.getString("description"));
	
	/**
	 * view��
	 */
	
	return roleBean;
	
}
//��õ�ǰid���û���Ȩ�޵�����
/*
 * select r.name from admin a left join t_roles r on a.roleid = r.id
   left join t_rolepermissions rp on rp.roleid = r.id where a.id =1 
 */
/**
 * ��ѯ����ǰ����Ա�Ľ�ɫ��Ϣ
 * @param username
 * @return
 */
	public RoleBean getRoleNameByUsername(String username) {
		
		    ResultSet rs=null;
			String sql = "select r.* from admin a left join t_roles r on a.roleid = r.id "+
   "   left join t_rolepermissions rp on rp.roleid = r.id where a.username ='"+username+"'";
				DBO dbo = new DBO();
				dbo.open();
				try{
					rs = dbo.executeQuery(sql);
					rs.next();
					return toModel(rs);
					
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					dbo.close();
				}
				return null;
	}
public int selectRoleByUsername(String username2) {
    
	ResultSet rs=null;
	
	DBO dbo = new DBO();
	dbo.open();
	try{
		//��ѯ����ǰusername�Ƿ��ǳ�������Ա
		rs = dbo.executeQuery("select r.name from admin a left join t_roles r on a.roleid = r.id where a.username ='"+username2+"'");
		rs.next();
		if(rs.getString("name").equals("ϵͳ����Ա"))
		{
			return Constant.SUCCESS;
		}
		else
		{
			return Constant.SYSTEM_ERROR;

		}
		
	}catch(Exception e){
		e.printStackTrace();
		return Constant.SYSTEM_ERROR;
	}finally{
		dbo.close();
	}
	
	
}
public void update(String name) {

	DBO dbo = new DBO();
	dbo.open();
	try{
		 dbo.executeUpdate("update t_permissions set isDeleted = 1 where name='"+name+"'");
	}
	catch(Exception e){
		
		throw new RuntimeException();
		
	}finally{
		dbo.close();
	}
	
	
	
}
public void rupdate(String name) {

	DBO dbo = new DBO();
	dbo.open();
	try{
		 dbo.executeUpdate("update t_permissions set isDeleted = 0 where name='"+name+"'");
	}
	catch(Exception e){
		
		throw new RuntimeException();
		
	}finally{
		dbo.close();
	}
	
	
	
}



}
