package com.bean;

import java.security.acl.Permission;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.util.Constant;
import com.util.DBO;

public class PermissionBean {

	
	private int id;
	private String name;
	private String description;
	private Boolean isDeleted;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	
	public PermissionBean toModel(ResultSet rs) throws SQLException
	{
		
		PermissionBean pb=new PermissionBean();
		pb.setIsDeleted(rs.getBoolean("isDeleted"));
		pb.setDescription(rs.getString("description"));
        pb.setId(rs.getInt("id"));
        pb.setName(rs.getString("name"));      		
		return pb;
			
	}
	
	/**
	 * ������еĿ����Ϣ
	 * @return
	 */
public  PermissionBean[] getAll()
{
	    ResultSet rs=null;
		String sql = "select * from t_permissions";
		DBO dbo = new DBO();
		List<PermissionBean> list = new ArrayList<PermissionBean>();
		dbo.open();
		try{
			rs = dbo.executeQuery(sql);
			while(rs.next())
			{
				list.add(toModel(rs));
			}	
			return (PermissionBean[]) list.toArray(new PermissionBean[list.size()]);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			dbo.close();
		}
		return null;
	}
	public int checkaffiche(String name) 
	{
		//��ѯ����ǰis deleted
            ResultSet rs=null;
			String sql = "select * from t_permissions where name='"+name+"' ";
			DBO dbo = new DBO();
			dbo.open();
			try{
				rs = dbo.executeQuery(sql);
				rs.next();
				Boolean b=rs.getBoolean("isDeleted");
				if(b==true)
				{
					return Constant.SUCCESS;
				}
				else
				{
					return Constant.SYSTEM_ERROR;
				}				
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				dbo.close();
			}
			return Constant.SYSTEM_ERROR;
		}
		
		
	
	
	
	
	
	
	
	
	
	
	
	
}
